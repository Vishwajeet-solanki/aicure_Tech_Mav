import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestRegressor
import joblib
import sys
import os

def train_model(X_train, y_train):
    # Standardize the features
    scaler = StandardScaler()

    # Initialize the model
    model = RandomForestRegressor()

    # Initialize Recursive Feature Elimination (RFE)
    rfe = RFE(model, n_features_to_select=None)

    # Fit RFE on the training data
    rfe.fit(X_train, y_train)

    # Get the selected features
    selected_features = X_train.columns[rfe.support_]

    # Train the model on the selected features
    X_train_selected = X_train[selected_features]
    model.fit(X_train_selected, y_train)

    return model, scaler, selected_features

def save_model(model, scaler, selected_features, model_filepath='trained_model.joblib'):
    # Save the trained model and relevant information
    joblib.dump({'model': model, 'scaler': scaler, 'selected_features': selected_features}, model_filepath)
    print(f"Model saved to {model_filepath}")

def load_model(model_filepath='trained_model.joblib'):
    # Load the trained model and relevant information
    if os.path.exists(model_filepath):
        model_data = joblib.load(model_filepath)
        model = model_data['model']
        scaler = model_data['scaler']
        selected_features = model_data['selected_features']
        print(f"Model loaded from {model_filepath}")
        return model, scaler, selected_features
    else:
        print(f"No existing model found in {model_filepath}")
        print("So Model training is getting started:")
        return None, None, None

def main(input_filepath, model_filepath='trained_model.joblib', results_filepath='results.csv'):
    # Load the training data
    df_train = pd.read_csv('./train_data.csv')

    # Selecting the columns of interest
    columns_of_interest = [
        'MEAN_RR', 'MEDIAN_RR', 'SDRR', 'RMSSD', 'SDSD', 'SDRR_RMSSD',
        'pNN25', 'pNN50', 'KURT', 'SKEW', 'MEAN_REL_RR', 'MEDIAN_REL_RR',
        'SDRR_REL_RR', 'RMSSD_REL_RR', 'SDSD_REL_RR', 'SDRR_RMSSD_REL_RR',
        'KURT_REL_RR', 'SKEW_REL_RR', 'VLF', 'VLF_PCT', 'LF', 'LF_PCT',
        'LF_NU', 'HF', 'HF_PCT', 'HF_NU', 'TP', 'LF_HF', 'HF_LF', 'SD1',
        'SD2', 'higuci', 'sampen'
    ]

    target_column = 'HR'

    X_train = df_train[columns_of_interest]
    y_train = df_train[target_column]

    # Load or train the model
    model, scaler, selected_features = load_model(model_filepath)
    if model is None:
        model, scaler, selected_features = train_model(X_train, y_train)
        save_model(model, scaler, selected_features, model_filepath)

    # Load the test data
    df_test = pd.read_csv(input_filepath)

    # Select features for test data
    X_test = df_test[columns_of_interest]

    # Standardize the features for test data
    X_test_selected = X_test[selected_features]

    # Make predictions on the test set
    y_pred = model.predict(X_test_selected)

    # Create a DataFrame with the predicted values and 'uuid'
    results_df = pd.DataFrame({'uuid': df_test['uuid'], 'HR': y_pred})

    # Save the results to a CSV file
    results_df.to_csv(results_filepath, index=False)
    print(f"Results saved to {results_filepath}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python run.py <input_filepath>")
        sys.exit(1)

    input_filepath = sys.argv[1]
    main(input_filepath)